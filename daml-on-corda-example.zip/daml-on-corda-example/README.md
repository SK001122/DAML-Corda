
# Examples using DAML on Corda

[Cake](cake) - Have Your Cake and Eat it with DAML on Corda

[Ticket](ticket) - Port of Chainstack's no-scalping CorDapp to DAML

[Issuance](issuance) - An example of a DAML schema for doing ticket issuance



rootProject.name = "noscalping"

